var ether_8h =
[
    [ "EXTERN", "group___s_o_c_k_e_t.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "ether_ntoa", "group___s_o_c_k_e_t.html#ga4b72f6638179fbe06d1cb560520d6efb", null ]
];