var mqueue_8h =
[
    [ "EXTERN", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "MQ_NONBLOCK", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#gab4e758a20a7f698126c36c5c2162a1ef", null ],
    [ "mqd_t", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga7903b465c5f2702f94428208a2707ddf", null ],
    [ "mq_close", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga3fbd3906296be63451c64d69be2bc371", null ],
    [ "mq_getattr", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga8e76060c59517151dc56f938b567e72a", null ],
    [ "mq_notify", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga5eadbb82e0b9702d77f384a27827b334", null ],
    [ "mq_open", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga8e9d61c726fc604daf9388cfee4f565e", null ],
    [ "mq_receive", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#gac64ec31e0df936132c8655189905b82b", null ],
    [ "mq_send", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga2e680a8cf14276928e0cc55536fcf4cb", null ],
    [ "mq_setattr", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga8ab65af064d6b25e5d752fc986ced5c0", null ],
    [ "mq_timedreceive", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#gaf33b63ecd9a907bb8e1f53990776eb1b", null ],
    [ "mq_timedsend", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga2a03f806a03992e95277d4c79d540e2d", null ],
    [ "mq_unlink", "group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga00f67358df4970aa7a7a5850bb05ff9a", null ]
];