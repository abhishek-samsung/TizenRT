var structsched__param =
[
    [ "sched_priority", "structsched__param.html#af839e8b89f27d3e4dcd7929e7edf9823", null ]
];