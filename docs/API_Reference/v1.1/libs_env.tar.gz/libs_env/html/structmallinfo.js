var structmallinfo =
[
    [ "arena", "structmallinfo.html#a7202a6840820bbf924bd78fef95420f8", null ],
    [ "fordblks", "structmallinfo.html#aa663a9275208b00d28cdce23f4a87931", null ],
    [ "mxordblk", "structmallinfo.html#aa2d54e6052204d784bc05e50b3310b91", null ],
    [ "ordblks", "structmallinfo.html#a6307b6068dec061900d98e9a5d7ef5c6", null ],
    [ "uordblks", "structmallinfo.html#a804ad590b4255be1047d1ce356de3754", null ]
];