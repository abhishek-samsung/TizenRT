var tinyara_2spawn_8h =
[
    [ "SIZEOF_OPEN_FILE_ACTION_S", "tinyara_2spawn_8h.html#a1222f93deeac832ef3ab4e9b703b0199", null ],
    [ "spawn_file_actions_e", "group___s_p_a_w_n___l_i_b_c.html#ga2e255d11578f1767f27c166393a0ee46", [
      [ "SPAWN_FILE_ACTION_NONE", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46a66be9c3493de6885caf68078f34b519d", null ],
      [ "SPAWN_FILE_ACTION_CLOSE", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46a3da7f89d8ee8ca09541a5e05e7d7a31b", null ],
      [ "SPAWN_FILE_ACTION_DUP2", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46ab72e94963864395895f8d0b4d65a5ee3", null ],
      [ "SPAWN_FILE_ACTION_OPEN", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46ab8d31c2b5dcf28a3e2a21fd752d72015", null ]
    ] ],
    [ "add_file_action", "group___s_p_a_w_n___l_i_b_c.html#ga89d4e1ff18d9f8fcda7c6c225b13044d", null ]
];