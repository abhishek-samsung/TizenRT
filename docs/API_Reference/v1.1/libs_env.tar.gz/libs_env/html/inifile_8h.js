var inifile_8h =
[
    [ "EXTERN", "inifile_8h.html#a77366c1bd428629dc898e188bfd182a3", null ],
    [ "INIHANDLE", "inifile_8h.html#ab629efe1def925ec982e41a5fe07f7e6", null ],
    [ "inifile_free_string", "inifile_8h.html#af238ef95f2957e41d2fa41dcc0a6b07a", null ],
    [ "inifile_initialize", "inifile_8h.html#a0de896ce05fe3468d903e3e93e09a952", null ],
    [ "inifile_read_integer", "inifile_8h.html#aff3e143bb51668864d552e33ed164ce7", null ],
    [ "inifile_read_string", "inifile_8h.html#a4310394b0c5f58ca3001fa211ea4a089", null ],
    [ "inifile_uninitialize", "inifile_8h.html#a3f4c1266e3f1e3e5227e49065c7be0cb", null ]
];