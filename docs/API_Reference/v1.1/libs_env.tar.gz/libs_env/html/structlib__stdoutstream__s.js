var structlib__stdoutstream__s =
[
    [ "public", "structlib__stdoutstream__s.html#aeeaaca22c06f00191d452e4bb1878464", null ],
    [ "stream", "structlib__stdoutstream__s.html#ae64992450acc585492de9edbca5fc826", null ]
];