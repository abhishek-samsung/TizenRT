var structspawn__close__file__action__s =
[
    [ "action", "structspawn__close__file__action__s.html#aeaed46203233f523a4ceffb2b30f0efd", null ],
    [ "fd", "structspawn__close__file__action__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "flink", "structspawn__close__file__action__s.html#a86f494c1496c2e0bb3a7761d3db0d05c", null ]
];