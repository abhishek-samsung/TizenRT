var structsched__message =
[
    [ "next_comm", "structsched__message.html#a4730972d30a61b98126d5d04f9c52785", null ],
    [ "next_pid", "structsched__message.html#a54a60f61f4b468b7e6ef164c4b5ba60b", null ],
    [ "next_prio", "structsched__message.html#a29f97eb549990cc6f72aae5ec2133f77", null ],
    [ "pad", "structsched__message.html#ae7dda5b3b6c7a3e2723078db06f5f10b", null ],
    [ "prev_comm", "structsched__message.html#ac93a9a5263da9019ffbb7505fa938675", null ],
    [ "prev_pid", "structsched__message.html#a71bb2f81a0788611ffb024cbdabd1c85", null ],
    [ "prev_prio", "structsched__message.html#ac791d1e6db1855bf9a1a21297b97b2fc", null ],
    [ "prev_state", "structsched__message.html#ac6e16956873f5113716688c481c39406", null ]
];