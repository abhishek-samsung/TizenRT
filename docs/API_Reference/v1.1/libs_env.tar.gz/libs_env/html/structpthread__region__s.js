var structpthread__region__s =
[
    [ "address", "structpthread__region__s.html#ab96816d317aa5196e2ef198d9a8d621b", null ],
    [ "attributes", "structpthread__region__s.html#a5b07acd04f2485df951064cfb9177ce3", null ],
    [ "size", "structpthread__region__s.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ]
];