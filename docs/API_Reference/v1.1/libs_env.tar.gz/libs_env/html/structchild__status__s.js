var structchild__status__s =
[
    [ "ch_flags", "structchild__status__s.html#a812cd2035ebd906c15bc6c468df0b6c1", null ],
    [ "ch_pid", "structchild__status__s.html#a8ad6ce3452d941f1a827c5746c689f00", null ],
    [ "ch_status", "structchild__status__s.html#a6169ce09cd142bca73b314eb69dbfc7e", null ],
    [ "flink", "structchild__status__s.html#a8f781bce389fe0b3c3962830469207f7", null ]
];