var structsq__queue__s =
[
    [ "head", "structsq__queue__s.html#a2ffe56067e548f5020477f1db6531696", null ],
    [ "tail", "structsq__queue__s.html#a6e229947eb845f0ee0c53e8abd5acbf4", null ]
];