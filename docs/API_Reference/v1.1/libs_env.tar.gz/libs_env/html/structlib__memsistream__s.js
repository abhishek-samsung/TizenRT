var structlib__memsistream__s =
[
    [ "buffer", "structlib__memsistream__s.html#a0f128ed7d962f6124bdc02b892953910", null ],
    [ "buflen", "structlib__memsistream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
    [ "offset", "structlib__memsistream__s.html#aadb6d6eb83e646653a1402032e45dcab", null ],
    [ "public", "structlib__memsistream__s.html#a0955f45b98cbb9b51a440a1b954165bb", null ]
];