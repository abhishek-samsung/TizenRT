/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Tizen RT Libs&Environment", "index.html", [
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"group___c_l_o_c_k___k_e_r_n_e_l.html#ga5d382db57f2975df15fd690dfcd37d38",
"group___d_e_b_u_g___k_e_r_n_e_l.html#gadd8b1b6ccc279c3ff810493328a61631",
"group___e_r_r_n_o___k_e_r_n_e_l.html#ga2f78c246352d2bf2f19dc5d43da2f0c9",
"group___e_r_r_n_o___k_e_r_n_e_l.html#gaac51995026fa19cdd0ad84a272304af0",
"group___f_c_n_t_l___k_e_r_n_e_l.html#gad39ebe4c4767eaa9a680777400cfaafe",
"group___i_o_c_t_l___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3",
"group___m_a_t_h___l_i_b_c.html#gad8d1296592a3e783acdd0de21ff58e2e",
"group___p_t_h_r_e_a_d___k_e_r_n_e_l.html#gadc009a2c805c3d0b98025998f0d5273f",
"group___s_i_g_n_a_l___k_e_r_n_e_l.html#ga796127b105a3d4ec9d2d3381cc93729e",
"group___s_p_a_w_n___l_i_b_c.html#ga6ee0850ba0d77610d610090eb39ad7c9",
"group___s_t_d_l_i_b___l_i_b_c.html#ga5402127cf3b439fbb504820ac39581a2",
"group___t_i_m_e___k_e_r_n_e_l.html#ga3868aa1fadfb79ce5e2584f0ba098a0f",
"pthread_8h.html#a715e9644a7183d98cb2c9dd41cb89645",
"structpollfd.html",
"termios_8h.html#a3b03fbde0d38a589a2d68c7c16770104"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';