var structlib__rawinstream__s =
[
    [ "fd", "structlib__rawinstream__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "public", "structlib__rawinstream__s.html#a287caaec902c6f6e83a40416c4dc2c1d", null ]
];