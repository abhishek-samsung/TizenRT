var structsigevent =
[
    [ "sigev_notify", "structsigevent.html#aecae3efd5c059655c6b3d998ffb275b0", null ],
    [ "sigev_signo", "structsigevent.html#a0d73d1b617d5b80c4d6959a9827339b5", null ],
    [ "sigev_value", "structsigevent.html#a15c47545bbb248076a6099282de41e9b", null ]
];