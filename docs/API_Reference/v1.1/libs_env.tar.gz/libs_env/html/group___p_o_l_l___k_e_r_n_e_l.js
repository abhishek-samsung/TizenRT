var group___p_o_l_l___k_e_r_n_e_l =
[
    [ "poll.h", "poll_8h.html", null ],
    [ "pollfd", "structpollfd.html", [
      [ "events", "structpollfd.html#a442f5a81fde427aec032b11f0448e992", null ],
      [ "fd", "structpollfd.html#a6f8059414f0228f0256115e024eeed4b", null ],
      [ "priv", "structpollfd.html#a20dbbd0eba0038e1c9b4c169b3becbd0", null ],
      [ "revents", "structpollfd.html#a847a1e5a35870f186846a4c724108879", null ],
      [ "sem", "structpollfd.html#a5c905d8d60d9e4d58e9a4a5ec07ec44c", null ]
    ] ],
    [ "EXTERN", "group___p_o_l_l___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "POLLERR", "group___p_o_l_l___k_e_r_n_e_l.html#gab1c532446408c98559d4aaaeeeb99820", null ],
    [ "POLLHUP", "group___p_o_l_l___k_e_r_n_e_l.html#ga262754fe6bdf27c2cd3da43284ec8536", null ],
    [ "POLLIN", "group___p_o_l_l___k_e_r_n_e_l.html#ga52ac479a805051f59643588b096024ff", null ],
    [ "POLLNVAL", "group___p_o_l_l___k_e_r_n_e_l.html#gae8bffe35c61e12fb7b408b89721896df", null ],
    [ "POLLOUT", "group___p_o_l_l___k_e_r_n_e_l.html#ga91b3c67129ac7675062f316b840a0d58", null ],
    [ "POLLPRI", "group___p_o_l_l___k_e_r_n_e_l.html#gab6f53b89c7a4cc5e8349f7c778d85168", null ],
    [ "POLLRDBAND", "group___p_o_l_l___k_e_r_n_e_l.html#ga37c71608162976b7fa0a5465009ce3ab", null ],
    [ "POLLRDNORM", "group___p_o_l_l___k_e_r_n_e_l.html#ga8ca81f2b28be692732d3f0b601fd828d", null ],
    [ "POLLWRBAND", "group___p_o_l_l___k_e_r_n_e_l.html#ga272636cc42f343281665cd1ba92f2f1e", null ],
    [ "POLLWRNORM", "group___p_o_l_l___k_e_r_n_e_l.html#gab8f1f69608ba2430cd5fa629a87b5420", null ],
    [ "nfds_t", "group___p_o_l_l___k_e_r_n_e_l.html#gaa49b6bf041fda66eda01c0170243c271", null ],
    [ "pollevent_t", "group___p_o_l_l___k_e_r_n_e_l.html#ga4d8ccbdde9a7b4b665fc97932e86bcf5", null ],
    [ "poll", "group___p_o_l_l___k_e_r_n_e_l.html#gaa8cba293d664129a2bbb3177c7b8c11e", null ]
];