var structtask__group__s =
[
    [ "flink", "structtask__group__s.html#aef980a3d39feec8e449dde75eb87278f", null ],
    [ "sigpendingq", "structtask__group__s.html#a3c146f2bf25fa1840d7210b8c12b71ab", null ],
    [ "tg_children", "structtask__group__s.html#a94d8872d5bd63a36b232f9e1718f17db", null ],
    [ "tg_envp", "structtask__group__s.html#af8250ed659cd0669492f5fbb94df776b", null ],
    [ "tg_envsize", "structtask__group__s.html#a31ace1cea55329d747fff36d3dc67c20", null ],
    [ "tg_filelist", "structtask__group__s.html#ae829ac4a8ceee608e501cc7a75a4429c", null ],
    [ "tg_flags", "structtask__group__s.html#a185c4165e86fd0e59173169557598e62", null ],
    [ "tg_gid", "structtask__group__s.html#ae41d19dd9cb1554623d6b07393f37446", null ],
    [ "tg_joinhead", "structtask__group__s.html#affc2c469ef93dfa0ce0430f12c89c319", null ],
    [ "tg_joinsem", "structtask__group__s.html#af58e2e85f61c30f9a7bcda0d036a2384", null ],
    [ "tg_jointail", "structtask__group__s.html#a7fe9bb519f9623644c5d6b452464a8c1", null ],
    [ "tg_members", "structtask__group__s.html#a501d63495e70c6fcf38886e3d1dd78d5", null ],
    [ "tg_msgdesq", "structtask__group__s.html#acfce8cffff4ca8c9283d0973e58cfe7b", null ],
    [ "tg_mxmembers", "structtask__group__s.html#a2cb52d3fca0982034c13d33db31f7054", null ],
    [ "tg_nkeys", "structtask__group__s.html#a45b2cfcb93e94751416bf7f965879502", null ],
    [ "tg_nmembers", "structtask__group__s.html#abfeebe3b22034fa08c65c03b54ceaea3", null ],
    [ "tg_onexitarg", "structtask__group__s.html#a5dbd7e911ce8224fdf6c264d414333cb", null ],
    [ "tg_onexitfunc", "structtask__group__s.html#a72efa343d3a328d03ad54582b75722a7", null ],
    [ "tg_pgid", "structtask__group__s.html#a3207f6390826071d57cbb447cb4a00f2", null ],
    [ "tg_task", "structtask__group__s.html#a17a2dd39f3d439156db8fdbcb0e0cea7", null ]
];