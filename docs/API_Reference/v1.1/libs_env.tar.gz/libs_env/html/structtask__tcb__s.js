var structtask__tcb__s =
[
    [ "argv", "structtask__tcb__s.html#aa5189ec135933f3a558ca38bb8685cbc", null ],
    [ "cmn", "structtask__tcb__s.html#ac9506bd169dd358b52b583a10ffb16ad", null ],
    [ "init_priority", "structtask__tcb__s.html#ab01fe7b208b9e11b0c9561c072092796", null ],
    [ "starthook", "structtask__tcb__s.html#acee1b4a1e003dff8364c6d55b45307a1", null ],
    [ "starthookarg", "structtask__tcb__s.html#a423869c98d523e38c98b1d3c2adb1e4d", null ]
];