var group___q_u_e_u_e___l_i_b_c =
[
    [ "queue.h", "queue_8h.html", null ],
    [ "sq_entry_s", "structsq__entry__s.html", [
      [ "flink", "structsq__entry__s.html#af902a91e021af91ace7a0159f44212d6", null ]
    ] ],
    [ "dq_entry_s", "structdq__entry__s.html", [
      [ "blink", "structdq__entry__s.html#a41c71fcde0480e617bccf1d90a8b4286", null ],
      [ "flink", "structdq__entry__s.html#a149bd86a7f713a627950c4f27e3c52b0", null ]
    ] ],
    [ "sq_queue_s", "structsq__queue__s.html", [
      [ "head", "structsq__queue__s.html#a2ffe56067e548f5020477f1db6531696", null ],
      [ "tail", "structsq__queue__s.html#a6e229947eb845f0ee0c53e8abd5acbf4", null ]
    ] ],
    [ "dq_queue_s", "structdq__queue__s.html", [
      [ "head", "structdq__queue__s.html#a0ea1decc78de44444b63484c92a4d627", null ],
      [ "tail", "structdq__queue__s.html#a7e523cd0e307830871e31036ff1313e7", null ]
    ] ],
    [ "dq_empty", "group___q_u_e_u_e___l_i_b_c.html#gaeef05ca124c8423f94d046ea6a0a42e8", null ],
    [ "dq_init", "group___q_u_e_u_e___l_i_b_c.html#ga9d25971fcfb25e413183f585e12c17db", null ],
    [ "dq_next", "group___q_u_e_u_e___l_i_b_c.html#ga711944efde92f0aaa717875247b1bb4e", null ],
    [ "dq_peek", "group___q_u_e_u_e___l_i_b_c.html#ga5d03e30c27f90d347e25a58a12ff9fe9", null ],
    [ "dq_prev", "group___q_u_e_u_e___l_i_b_c.html#gaf2f2f34b78b4cf7fe60e312a5a95ccaa", null ],
    [ "EXTERN", "group___q_u_e_u_e___l_i_b_c.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "sq_empty", "group___q_u_e_u_e___l_i_b_c.html#ga52be362269347b9c7d91ba70bdc659ac", null ],
    [ "sq_init", "group___q_u_e_u_e___l_i_b_c.html#gab9ab3552452d53e24f00b9d26c83248e", null ],
    [ "sq_next", "group___q_u_e_u_e___l_i_b_c.html#gae2de657f56b84125ef16f1efbab7ab4d", null ],
    [ "sq_peek", "group___q_u_e_u_e___l_i_b_c.html#ga678c04869256dbc9baae17e9e3161074", null ],
    [ "dq_entry_t", "group___q_u_e_u_e___l_i_b_c.html#gac3f015c0d8692f3acd1cced028e4c59d", null ],
    [ "dq_queue_t", "group___q_u_e_u_e___l_i_b_c.html#ga24c26e3f971325b6324ef83fb6ac479d", null ],
    [ "sq_entry_t", "group___q_u_e_u_e___l_i_b_c.html#ga17d0d32195f92dcda6268743c956230c", null ],
    [ "sq_queue_t", "group___q_u_e_u_e___l_i_b_c.html#gaadc0b747571c18376b0941f690b70043", null ],
    [ "dq_addafter", "group___q_u_e_u_e___l_i_b_c.html#gae7ab184fed09af3e6685338a67b03b1b", null ],
    [ "dq_addbefore", "group___q_u_e_u_e___l_i_b_c.html#ga79e3ff416e30704e47ea6012f75926ac", null ],
    [ "dq_addfirst", "group___q_u_e_u_e___l_i_b_c.html#gab83c2a313c45a5eac0e48d6b82054791", null ],
    [ "dq_addlast", "group___q_u_e_u_e___l_i_b_c.html#ga1a1467343e8e3ddb23a6e230957e006a", null ],
    [ "dq_rem", "group___q_u_e_u_e___l_i_b_c.html#gac51f66188f1614f78c2de75433d30535", null ],
    [ "dq_remfirst", "group___q_u_e_u_e___l_i_b_c.html#gaccecc7059a73ae507a3ffff3a22252a7", null ],
    [ "dq_remlast", "group___q_u_e_u_e___l_i_b_c.html#gad681bfd8443977a32d5e50d5d8d69361", null ],
    [ "sq_addafter", "group___q_u_e_u_e___l_i_b_c.html#gaf12cac74535826c63d1c4831377427d5", null ],
    [ "sq_addfirst", "group___q_u_e_u_e___l_i_b_c.html#ga63c7d42440e02d85acd1842d79ea6939", null ],
    [ "sq_addlast", "group___q_u_e_u_e___l_i_b_c.html#ga09b54be74fbd4322e3a098d72598c666", null ],
    [ "sq_rem", "group___q_u_e_u_e___l_i_b_c.html#ga4872167453b4a229a79d9c4a407ef03a", null ],
    [ "sq_remafter", "group___q_u_e_u_e___l_i_b_c.html#ga9b1ddb4bf0786110444becc41aed1dd4", null ],
    [ "sq_remfirst", "group___q_u_e_u_e___l_i_b_c.html#gac5b5f525daa19f85ada3430d089514ba", null ],
    [ "sq_remlast", "group___q_u_e_u_e___l_i_b_c.html#ga6f105bd1d9c508d858b73ee36de9e96b", null ]
];