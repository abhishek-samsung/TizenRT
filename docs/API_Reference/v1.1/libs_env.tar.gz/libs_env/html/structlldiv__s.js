var structlldiv__s =
[
    [ "quot", "structlldiv__s.html#ac4000ffefcdd50a3cd0dc04fabfcce34", null ],
    [ "rem", "structlldiv__s.html#a7c04b7afc95e3cc4480a634f3073ba8a", null ]
];