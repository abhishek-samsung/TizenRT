var crc32_8h =
[
    [ "EXTERN", "group___c_r_c___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "crc32", "group___c_r_c___k_e_r_n_e_l.html#ga9b75c5537b13704c27bd1a0bb6bef2cb", null ],
    [ "crc32part", "group___c_r_c___k_e_r_n_e_l.html#gab96879e4838dd5d30d635fa8918c2e74", null ]
];