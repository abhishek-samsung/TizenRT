var structnetent =
[
    [ "n_addrtype", "structnetent.html#ac4f41bb53561445aba12832f4dfaa2bc", null ],
    [ "n_aliases", "structnetent.html#aedf9ce37c2b470078d7ba1afdb9451ec", null ],
    [ "n_name", "structnetent.html#ae60c67730147db77d45e493c6995d9c7", null ],
    [ "n_net", "structnetent.html#a1bb5e87d94eafac0f0ac1be2db689b25", null ]
];