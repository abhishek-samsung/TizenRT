var structlib__stdsistream__s =
[
    [ "public", "structlib__stdsistream__s.html#a0955f45b98cbb9b51a440a1b954165bb", null ],
    [ "stream", "structlib__stdsistream__s.html#ae64992450acc585492de9edbca5fc826", null ]
];