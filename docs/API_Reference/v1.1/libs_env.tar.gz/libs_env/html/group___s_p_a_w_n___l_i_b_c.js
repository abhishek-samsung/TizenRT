var group___s_p_a_w_n___l_i_b_c =
[
    [ "posix_spawnattr_s", "structposix__spawnattr__s.html", [
      [ "flags", "structposix__spawnattr__s.html#aa2585d779da0ab21273a8d92de9a0ebe", null ],
      [ "policy", "structposix__spawnattr__s.html#a6b22d59f607ab98e910257c4e97a343a", null ],
      [ "priority", "structposix__spawnattr__s.html#a0ad043071ccc7a261d79a759dc9c6f0c", null ],
      [ "sigmask", "structposix__spawnattr__s.html#a84a273d642c19957017a87b1f54031e6", null ],
      [ "stacksize", "structposix__spawnattr__s.html#ac6351740c6b6c1ea66b5723e19ff8ca2", null ]
    ] ],
    [ "spawn_general_file_action_s", "structspawn__general__file__action__s.html", [
      [ "action", "structspawn__general__file__action__s.html#aeaed46203233f523a4ceffb2b30f0efd", null ],
      [ "flink", "structspawn__general__file__action__s.html#a86f494c1496c2e0bb3a7761d3db0d05c", null ]
    ] ],
    [ "spawn_close_file_action_s", "structspawn__close__file__action__s.html", [
      [ "action", "structspawn__close__file__action__s.html#aeaed46203233f523a4ceffb2b30f0efd", null ],
      [ "fd", "structspawn__close__file__action__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
      [ "flink", "structspawn__close__file__action__s.html#a86f494c1496c2e0bb3a7761d3db0d05c", null ]
    ] ],
    [ "spawn_dup2_file_action_s", "structspawn__dup2__file__action__s.html", [
      [ "action", "structspawn__dup2__file__action__s.html#aeaed46203233f523a4ceffb2b30f0efd", null ],
      [ "fd1", "structspawn__dup2__file__action__s.html#ac62faf1ed925a0da21ba52b228cb9a47", null ],
      [ "fd2", "structspawn__dup2__file__action__s.html#af65d853335a6d8ffc28a26269ade6e5d", null ],
      [ "flink", "structspawn__dup2__file__action__s.html#a86f494c1496c2e0bb3a7761d3db0d05c", null ]
    ] ],
    [ "spawn_open_file_action_s", "structspawn__open__file__action__s.html", [
      [ "action", "structspawn__open__file__action__s.html#aeaed46203233f523a4ceffb2b30f0efd", null ],
      [ "fd", "structspawn__open__file__action__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
      [ "flink", "structspawn__open__file__action__s.html#a86f494c1496c2e0bb3a7761d3db0d05c", null ],
      [ "mode", "structspawn__open__file__action__s.html#adc8d3cf511ceb277aea0cfa1cd027c59", null ],
      [ "oflags", "structspawn__open__file__action__s.html#ad059e7b9fff7394a6042adf9bcc062ed", null ],
      [ "path", "structspawn__open__file__action__s.html#a8ad83d8773a5e65437ce4296f9fd17b7", null ]
    ] ],
    [ "CONFIG_TASK_SPAWN_DEFAULT_STACKSIZE", "group___s_p_a_w_n___l_i_b_c.html#ga4d978159be2ad68dcbded20cd9fa170e", null ],
    [ "POSIX_SPAWN_RESETIDS", "group___s_p_a_w_n___l_i_b_c.html#ga95bd34d45996db6ebf7cca56d4e1d41f", null ],
    [ "POSIX_SPAWN_SETPGROUP", "group___s_p_a_w_n___l_i_b_c.html#gacaeb1722f464b53521421824f6c6917b", null ],
    [ "POSIX_SPAWN_SETSCHEDPARAM", "group___s_p_a_w_n___l_i_b_c.html#gaa068a29021ea19dc85476b35393d9841", null ],
    [ "POSIX_SPAWN_SETSCHEDULER", "group___s_p_a_w_n___l_i_b_c.html#ga1c0a55cf4dcda3f295e47db6404a459e", null ],
    [ "POSIX_SPAWN_SETSIGDEF", "group___s_p_a_w_n___l_i_b_c.html#ga5916488b8b791ac3fc63ec854cff303b", null ],
    [ "POSIX_SPAWN_SETSIGMASK", "group___s_p_a_w_n___l_i_b_c.html#ga92388e472f8e3d09618a4f637e2a2690", null ],
    [ "posix_spawnattr_destroy", "group___s_p_a_w_n___l_i_b_c.html#ga2930673d2764fe248df88d3456f92055", null ],
    [ "posix_spawnattr_getpgroup", "group___s_p_a_w_n___l_i_b_c.html#ga6ee0850ba0d77610d610090eb39ad7c9", null ],
    [ "posix_spawnattr_getsigdefault", "group___s_p_a_w_n___l_i_b_c.html#ga50d8e6d251b9b32bc7ba8e5b878b37c2", null ],
    [ "posix_spawnattr_setpgroup", "group___s_p_a_w_n___l_i_b_c.html#gaac35b346c3c2f64f359046c4028254f1", null ],
    [ "posix_spawnattr_setsigdefault", "group___s_p_a_w_n___l_i_b_c.html#gaade9f1c4782f7297b0be36654f6a29a2", null ],
    [ "posix_spawn_file_actions_t", "group___s_p_a_w_n___l_i_b_c.html#ga0569444cf792a8fd114141caceb07031", null ],
    [ "posix_spawnattr_t", "group___s_p_a_w_n___l_i_b_c.html#ga25206d831127642fecb12702ae285f86", null ],
    [ "spawn_file_actions_e", "group___s_p_a_w_n___l_i_b_c.html#ga2e255d11578f1767f27c166393a0ee46", [
      [ "SPAWN_FILE_ACTION_NONE", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46a66be9c3493de6885caf68078f34b519d", null ],
      [ "SPAWN_FILE_ACTION_CLOSE", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46a3da7f89d8ee8ca09541a5e05e7d7a31b", null ],
      [ "SPAWN_FILE_ACTION_DUP2", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46ab72e94963864395895f8d0b4d65a5ee3", null ],
      [ "SPAWN_FILE_ACTION_OPEN", "group___s_p_a_w_n___l_i_b_c.html#gga2e255d11578f1767f27c166393a0ee46ab8d31c2b5dcf28a3e2a21fd752d72015", null ]
    ] ],
    [ "add_file_action", "group___s_p_a_w_n___l_i_b_c.html#ga89d4e1ff18d9f8fcda7c6c225b13044d", null ],
    [ "posix_spawn_file_actions_addclose", "group___s_p_a_w_n___l_i_b_c.html#ga9a48425cb33a1d4c49bef9560808ec61", null ],
    [ "posix_spawn_file_actions_adddup2", "group___s_p_a_w_n___l_i_b_c.html#ga76e8bb48939798a74b192834e0e0795b", null ],
    [ "posix_spawn_file_actions_addopen", "group___s_p_a_w_n___l_i_b_c.html#ga514c58f7ae4baa19c814ec98ef8b45b7", null ],
    [ "posix_spawn_file_actions_destroy", "group___s_p_a_w_n___l_i_b_c.html#ga26b7e167e2d9565c88228f74a3657b78", null ],
    [ "posix_spawn_file_actions_dump", "group___s_p_a_w_n___l_i_b_c.html#ga96bfd5af00f19b6e2fe7997a261deb5e", null ],
    [ "posix_spawn_file_actions_init", "group___s_p_a_w_n___l_i_b_c.html#ga1570fb4ada8903ea42e064311bee7f8e", null ],
    [ "posix_spawnattr_dump", "group___s_p_a_w_n___l_i_b_c.html#ga05a38577c4c331659b8c9ae69aebdff0", null ],
    [ "posix_spawnattr_getflags", "group___s_p_a_w_n___l_i_b_c.html#gaa87259abd7ff99f7cbf8a114ca58fed9", null ],
    [ "posix_spawnattr_getschedparam", "group___s_p_a_w_n___l_i_b_c.html#gadbe8bfdb274a9108efb2472ccc760fe7", null ],
    [ "posix_spawnattr_getschedpolicy", "group___s_p_a_w_n___l_i_b_c.html#ga4e741531106806c930fbea94e7af5285", null ],
    [ "posix_spawnattr_getsigmask", "group___s_p_a_w_n___l_i_b_c.html#ga691e33307797ba84a91da3d6585ef682", null ],
    [ "posix_spawnattr_init", "group___s_p_a_w_n___l_i_b_c.html#gaf8f3930ff49385ae01cd41313efe5346", null ],
    [ "posix_spawnattr_setflags", "group___s_p_a_w_n___l_i_b_c.html#ga17fbaf36a24064318dd97e6ce621889d", null ],
    [ "posix_spawnattr_setschedparam", "group___s_p_a_w_n___l_i_b_c.html#ga6807e6326df51576318b7c2efc4bb94a", null ],
    [ "posix_spawnattr_setschedpolicy", "group___s_p_a_w_n___l_i_b_c.html#ga32eb924e2ccfb2fa6e3ce4ec9f314f31", null ],
    [ "posix_spawnattr_setsigmask", "group___s_p_a_w_n___l_i_b_c.html#ga1cba24835c8f256c0ff80d0b6457661c", null ],
    [ "task_spawnattr_getstacksize", "group___s_p_a_w_n___l_i_b_c.html#gadf9915093f9c2e3f5702095eb912d2af", null ],
    [ "task_spawnattr_setstacksize", "group___s_p_a_w_n___l_i_b_c.html#ga3524dfc4efd86621d8f68815cf77b242", null ]
];