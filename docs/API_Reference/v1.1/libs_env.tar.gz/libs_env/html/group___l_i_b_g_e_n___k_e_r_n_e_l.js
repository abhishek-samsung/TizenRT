var group___l_i_b_g_e_n___k_e_r_n_e_l =
[
    [ "libgen.h", "libgen_8h.html", null ],
    [ "EXTERN", "group___l_i_b_g_e_n___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "basename", "group___l_i_b_g_e_n___k_e_r_n_e_l.html#ga8cf763885c412f1e403e13f251f802d4", null ],
    [ "dirname", "group___l_i_b_g_e_n___k_e_r_n_e_l.html#ga1c4bb0d6889d379103775b20a9eb257e", null ]
];