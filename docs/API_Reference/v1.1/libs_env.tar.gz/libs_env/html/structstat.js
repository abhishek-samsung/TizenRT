var structstat =
[
    [ "st_atime", "structstat.html#a830610c1aa2efb228f4c93752fac5c20", null ],
    [ "st_blksize", "structstat.html#aaa1efdec8c931915ea1945a61573438b", null ],
    [ "st_blocks", "structstat.html#aa9937b5892f150337565893360cd1ded", null ],
    [ "st_ctime", "structstat.html#a4e5382a4b12f6f9396a019b5d6e3e0ed", null ],
    [ "st_mode", "structstat.html#aee5b542fc82f176aad79ec67feb729c8", null ],
    [ "st_mtime", "structstat.html#aed5cb4c6ec394fc6629432f91d3719f9", null ],
    [ "st_size", "structstat.html#a4de8e8d5f90f6deec5e71e2105ee93f9", null ]
];