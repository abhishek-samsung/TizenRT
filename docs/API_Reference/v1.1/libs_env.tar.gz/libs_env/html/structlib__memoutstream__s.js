var structlib__memoutstream__s =
[
    [ "buffer", "structlib__memoutstream__s.html#adc743ae92a4a3617eba532437879e25d", null ],
    [ "buflen", "structlib__memoutstream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
    [ "public", "structlib__memoutstream__s.html#aeeaaca22c06f00191d452e4bb1878464", null ]
];