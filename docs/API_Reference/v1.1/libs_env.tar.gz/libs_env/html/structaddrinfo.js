var structaddrinfo =
[
    [ "ai_addr", "structaddrinfo.html#ad3a2b0a4cbcf9137e63d34d63dcbb336", null ],
    [ "ai_addrlen", "structaddrinfo.html#a187d9f4b7621e44cae73ddd9dab76a61", null ],
    [ "ai_canonname", "structaddrinfo.html#ab896f2231b832c676e1566e04743d69a", null ],
    [ "ai_family", "structaddrinfo.html#a4dc44d22f13bc5c59bff73e549e96a5c", null ],
    [ "ai_flags", "structaddrinfo.html#a92528a848ebf34ab99687dd06a09cc93", null ],
    [ "ai_next", "structaddrinfo.html#ace5518b32d5054c0ed2d3f7c355c965d", null ],
    [ "ai_protocol", "structaddrinfo.html#a6ade486587feaa03d492eb84cfc83451", null ],
    [ "ai_socktype", "structaddrinfo.html#a2109130e73586150c41fed16311e1af6", null ]
];