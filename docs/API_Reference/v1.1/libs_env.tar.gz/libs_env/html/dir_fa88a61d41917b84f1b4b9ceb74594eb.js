var dir_fa88a61d41917b84f1b4b9ceb74594eb =
[
    [ "configdata.h", "configdata_8h.html", null ]
];