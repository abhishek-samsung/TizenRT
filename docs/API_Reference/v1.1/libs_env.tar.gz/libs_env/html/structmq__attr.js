var structmq__attr =
[
    [ "mq_curmsgs", "structmq__attr.html#aa7c86659d004646d392fd20a8a3cf0ef", null ],
    [ "mq_flags", "structmq__attr.html#a615adee071169a107cbd51c1c7ec7bca", null ],
    [ "mq_maxmsg", "structmq__attr.html#ac9abf46833b6c01cf50a562f6753184e", null ],
    [ "mq_msgsize", "structmq__attr.html#aed10ae825de18ea55ca8ae110dbd654e", null ]
];