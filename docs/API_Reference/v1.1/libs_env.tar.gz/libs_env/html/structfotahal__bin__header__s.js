var structfotahal__bin__header__s =
[
    [ "fotahal_bin_id", "structfotahal__bin__header__s.html#a4a6dd78f279136146e3ad222ac6693aa", null ],
    [ "fotahal_bin_partaddr", "structfotahal__bin__header__s.html#a066b067249ceda3b81597cd0c72f71e4", null ],
    [ "fotahal_bin_reserved", "structfotahal__bin__header__s.html#a3ffc6ee093a8dc1d052ea30fe1d48d87", null ],
    [ "fotahal_bin_size", "structfotahal__bin__header__s.html#a2b49c8d20ca76733fe642f4215ad6c8c", null ],
    [ "fotahal_checksum", "structfotahal__bin__header__s.html#abc71214667fe1be79c8b006b33af8f4e", null ],
    [ "fotahal_magic", "structfotahal__bin__header__s.html#aef63a919bb7f0aea7d9d85a137e51d36", null ]
];