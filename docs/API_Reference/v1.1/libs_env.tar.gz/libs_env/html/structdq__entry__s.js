var structdq__entry__s =
[
    [ "blink", "structdq__entry__s.html#a41c71fcde0480e617bccf1d90a8b4286", null ],
    [ "flink", "structdq__entry__s.html#a149bd86a7f713a627950c4f27e3c52b0", null ]
];