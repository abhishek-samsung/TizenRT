var structdq__queue__s =
[
    [ "head", "structdq__queue__s.html#a0ea1decc78de44444b63484c92a4d627", null ],
    [ "tail", "structdq__queue__s.html#a7e523cd0e307830871e31036ff1313e7", null ]
];