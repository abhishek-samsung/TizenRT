var structtm =
[
    [ "tm_hour", "structtm.html#a4d171061df9e012fcfbd1172b8440d5f", null ],
    [ "tm_mday", "structtm.html#a02048604d30b880033311cf542d63f92", null ],
    [ "tm_min", "structtm.html#a987fa9280fe4cd6c6b8f77409f1c1504", null ],
    [ "tm_mon", "structtm.html#ada983deda100b604bee5716512453658", null ],
    [ "tm_sec", "structtm.html#a18df301c1a10c8d493da86ce5c2aea78", null ],
    [ "tm_year", "structtm.html#a994c4f4519ba57e186580d21cc86f9e5", null ]
];