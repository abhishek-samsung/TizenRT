var structposix__spawnattr__s =
[
    [ "flags", "structposix__spawnattr__s.html#aa2585d779da0ab21273a8d92de9a0ebe", null ],
    [ "policy", "structposix__spawnattr__s.html#a6b22d59f607ab98e910257c4e97a343a", null ],
    [ "priority", "structposix__spawnattr__s.html#a0ad043071ccc7a261d79a759dc9c6f0c", null ],
    [ "sigmask", "structposix__spawnattr__s.html#a84a273d642c19957017a87b1f54031e6", null ],
    [ "stacksize", "structposix__spawnattr__s.html#ac6351740c6b6c1ea66b5723e19ff8ca2", null ]
];