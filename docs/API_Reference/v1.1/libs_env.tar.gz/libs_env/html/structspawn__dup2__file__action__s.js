var structspawn__dup2__file__action__s =
[
    [ "action", "structspawn__dup2__file__action__s.html#aeaed46203233f523a4ceffb2b30f0efd", null ],
    [ "fd1", "structspawn__dup2__file__action__s.html#ac62faf1ed925a0da21ba52b228cb9a47", null ],
    [ "fd2", "structspawn__dup2__file__action__s.html#af65d853335a6d8ffc28a26269ade6e5d", null ],
    [ "flink", "structspawn__dup2__file__action__s.html#a86f494c1496c2e0bb3a7761d3db0d05c", null ]
];