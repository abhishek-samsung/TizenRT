var dir_4bb326a59d538673ef0ad2559ef291fd =
[
    [ "ioctl.h", "ioctl_8h.html", "ioctl_8h" ],
    [ "mount.h", "mount_8h.html", "mount_8h" ],
    [ "prctl.h", "prctl_8h.html", "prctl_8h" ],
    [ "select.h", "select_8h.html", "select_8h" ],
    [ "socket.h", "socket_8h.html", "socket_8h" ],
    [ "stat.h", "stat_8h.html", "stat_8h" ],
    [ "time.h", "sys_2time_8h.html", "sys_2time_8h" ],
    [ "wait.h", "wait_8h.html", "wait_8h" ]
];