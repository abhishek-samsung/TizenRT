var searchData=
[
  ['quot',['quot',['../structdiv__s.html#a2065955c249938f83ebf6bc6c07b4200',1,'div_s::quot()'],['../structldiv__s.html#ac4000ffefcdd50a3cd0dc04fabfcce34',1,'ldiv_s::quot()'],['../structlldiv__s.html#ac4000ffefcdd50a3cd0dc04fabfcce34',1,'lldiv_s::quot()']]]
];
