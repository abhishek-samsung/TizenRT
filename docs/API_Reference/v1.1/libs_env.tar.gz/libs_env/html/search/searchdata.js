var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz",
  1: "acdefhilmnpst",
  2: "abcdefhilmnpqrstuw",
  3: "abcdefghijklmnopqrstuvwyz",
  4: "_abcdefghijlmnopqrstuwx",
  5: "_abcdefilmnopstu",
  6: "fist",
  7: "fnpst",
  8: "_bcefghilmnoprstvwx",
  9: "acdefiklmnpqrstu",
  10: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

