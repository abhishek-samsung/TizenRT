var searchData=
[
  ['regex',['REGEX',['../group___r_e_g_e_x___k_e_r_n_e_l.html',1,'']]]
];
