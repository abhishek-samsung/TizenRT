var searchData=
[
  ['addrinfo',['addrinfo',['../structaddrinfo.html',1,'']]]
];
