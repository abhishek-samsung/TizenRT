var searchData=
[
  ['onexitfunc_5ft',['onexitfunc_t',['../tinyara_2sched_8h.html#a4267236ac89d7f0be34d2966e9d3179e',1,'sched.h']]]
];
