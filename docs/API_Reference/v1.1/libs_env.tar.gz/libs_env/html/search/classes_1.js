var searchData=
[
  ['child_5fstatus_5fs',['child_status_s',['../structchild__status__s.html',1,'']]]
];
