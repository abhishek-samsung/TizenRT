var structpthread__barrierattr__s =
[
    [ "pshared", "structpthread__barrierattr__s.html#a18379afcdbe1f4e88aede68b930003ca", null ]
];