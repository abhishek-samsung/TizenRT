var files_dup =
[
    [ "apps", "dir_9654b8d08f4bba4e84b362c5fd320bee.html", "dir_9654b8d08f4bba4e84b362c5fd320bee" ],
    [ "external", "dir_397d9aeee4af8edecac90968d93b57df.html", "dir_397d9aeee4af8edecac90968d93b57df" ],
    [ "os", "dir_8b7cb6c889a10e2a101a7e90c854ca4d.html", "dir_8b7cb6c889a10e2a101a7e90c854ca4d" ]
];