var structlib__outstream__s =
[
    [ "nput", "structlib__outstream__s.html#af55bde58b75130c4be39abdafaca70e5", null ],
    [ "put", "structlib__outstream__s.html#abad7053496488be482fafc150f72267d", null ]
];