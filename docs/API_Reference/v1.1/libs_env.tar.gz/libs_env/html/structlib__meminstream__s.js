var structlib__meminstream__s =
[
    [ "buffer", "structlib__meminstream__s.html#a0f128ed7d962f6124bdc02b892953910", null ],
    [ "buflen", "structlib__meminstream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
    [ "public", "structlib__meminstream__s.html#a287caaec902c6f6e83a40416c4dc2c1d", null ]
];