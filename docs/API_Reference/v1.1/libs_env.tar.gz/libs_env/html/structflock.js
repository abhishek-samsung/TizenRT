var structflock =
[
    [ "l_len", "structflock.html#af8e8f28ad45cb785a9dff9e911c7d061", null ],
    [ "l_pid", "structflock.html#aa0c39d4b312788ce580c742fd428d9f9", null ],
    [ "l_start", "structflock.html#a40b963d08d293decef4ffc56233c6df3", null ],
    [ "l_type", "structflock.html#a354f5c2b08d7c70d2942defb829c0951", null ],
    [ "l_whence", "structflock.html#a9bb1387fcea317005f3b83a6372ff657", null ]
];