var structtimezone =
[
    [ "tz_dsttime", "structtimezone.html#a1735bdac33175b31d7110accc8525064", null ],
    [ "tz_minuteswest", "structtimezone.html#a4a75d63d453836e8445d592840bb5de7", null ]
];