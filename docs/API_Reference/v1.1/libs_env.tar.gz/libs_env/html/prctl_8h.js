var prctl_8h =
[
    [ "EXTERN", "prctl_8h.html#a77366c1bd428629dc898e188bfd182a3", null ],
    [ "PR_GET_NAME", "group___s_c_h_e_d___k_e_r_n_e_l.html#ga35060be8f8c44ab467ba623982c13c7e", null ],
    [ "PR_SET_NAME", "group___s_c_h_e_d___k_e_r_n_e_l.html#ga97ef9de26ed4a2c36c77228e462fd85c", null ],
    [ "prctl", "group___s_c_h_e_d___k_e_r_n_e_l.html#ga4747c7331c5377775f2d2c133618ca63", null ]
];