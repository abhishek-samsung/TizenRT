var structsem__s =
[
    [ "flags", "structsem__s.html#aa2585d779da0ab21273a8d92de9a0ebe", null ],
    [ "hhead", "structsem__s.html#aea49aff8c6d1dc7c6b3c5d06dc861446", null ],
    [ "semcount", "structsem__s.html#a79a6d245cb1295cccd31fa97f81b0e24", null ]
];