var structtrace__packet =
[
    [ "codelen", "structtrace__packet.html#ac24d4d7ec1d53bb4da68756a00c72710", null ],
    [ "event_type", "structtrace__packet.html#a31642948667912627b6722a938e8b3d2", null ],
    [ "msg", "structtrace__packet.html#ae53f08f2b1ba6c39de2f831cb88cf56d", null ],
    [ "pid", "structtrace__packet.html#ae0d46a978d5cd6707411f276ad869b9c", null ],
    [ "ts", "structtrace__packet.html#a21be78b2818c91cb205885b8a6f5aed8", null ]
];