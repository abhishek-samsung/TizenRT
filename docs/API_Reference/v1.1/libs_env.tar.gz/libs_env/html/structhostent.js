var structhostent =
[
    [ "h_addr_list", "structhostent.html#a2795f2a983377d5c5784557267640aa5", null ],
    [ "h_addrtype", "structhostent.html#a913b2bbf34d26ed76f7109a7a17bf4a3", null ],
    [ "h_aliases", "structhostent.html#a52fad4641d86a4146a81ca1e9f89ff06", null ],
    [ "h_length", "structhostent.html#aa5906b78ee4dffe8785c3d40de2e69f5", null ],
    [ "h_name", "structhostent.html#a7cb60cbcce9b6136ccc3bbf9a5309707", null ]
];