var structservent =
[
    [ "s_aliases", "structservent.html#a7789708a08faf28015a7f4d01eb7d5d2", null ],
    [ "s_name", "structservent.html#ae42ea8d37c0280417bf2b5539758311f", null ],
    [ "s_port", "structservent.html#a64a4e967ab04459f1c52927c32bede66", null ],
    [ "s_proto", "structservent.html#a079e85711f9800e7455fd48506651bd2", null ]
];