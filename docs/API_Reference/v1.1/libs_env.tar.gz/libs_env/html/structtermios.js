var structtermios =
[
    [ "c_cc", "structtermios.html#a06ea1504c051c8b60c9e5d04b63877dd", null ],
    [ "c_cflag", "structtermios.html#ac6409888277d696c033f0068b33d5acc", null ],
    [ "c_iflag", "structtermios.html#a3e416181096da14aacc3a5aaa3138d3e", null ],
    [ "c_lflag", "structtermios.html#ad03044b6d30bc840e24751ea465651af", null ],
    [ "c_oflag", "structtermios.html#a615efcbde1bbfd1f2c28b3a62bd05add", null ],
    [ "c_speed", "structtermios.html#a9b14ff83a882d409ce372efd707f76f4", null ]
];