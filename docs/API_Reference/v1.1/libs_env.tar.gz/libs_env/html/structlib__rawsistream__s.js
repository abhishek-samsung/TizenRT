var structlib__rawsistream__s =
[
    [ "fd", "structlib__rawsistream__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "public", "structlib__rawsistream__s.html#a0955f45b98cbb9b51a440a1b954165bb", null ]
];