var structlib__sistream__s =
[
    [ "get", "structlib__sistream__s.html#a2404695066db4dabb754b034b894bd89", null ],
    [ "nget", "structlib__sistream__s.html#a5569072b97423681526c03c1d2c60fc5", null ],
    [ "seek", "structlib__sistream__s.html#a477da61effd4ea0669b0771ff5cfdad2", null ]
];