var structlib__instream__s =
[
    [ "get", "structlib__instream__s.html#ac1e61219acdbdf0f832f5cdc17bd14bc", null ],
    [ "nget", "structlib__instream__s.html#a5569072b97423681526c03c1d2c60fc5", null ]
];