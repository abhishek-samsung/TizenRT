var structsemholder__s =
[
    [ "counts", "structsemholder__s.html#ad5daea048a26df74654c14cf74f5e649", null ],
    [ "flink", "structsemholder__s.html#a096d555130ebfe80e358ea6ed9f73040", null ],
    [ "htcb", "structsemholder__s.html#a5e905b458a3ececa661606dee4d66900", null ]
];