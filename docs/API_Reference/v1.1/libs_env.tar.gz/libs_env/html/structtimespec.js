var structtimespec =
[
    [ "tv_nsec", "structtimespec.html#a87f023ba4df946995ed7434144501c4a", null ],
    [ "tv_sec", "structtimespec.html#a232bceb4df3143c722275e6b22f605b9", null ]
];